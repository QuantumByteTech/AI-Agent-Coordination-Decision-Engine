# AI Agent Coordination & Decision Engine — Fresh Frontend

This is a standalone frontend created specifically for the current project.
It does not reuse the previous WorkSphere UI.

## Stack

- HTML5
- CSS3
- Vanilla JavaScript
- Python standard-library development server
- Existing FastAPI backend

No paid services or frontend frameworks are required.

## Run

1. Start the existing FastAPI backend first:

```bash
uvicorn app.api.main:app --reload
```

2. Open a second Git Bash terminal and enter this frontend folder.

3. Start the frontend:

```bash
python server.py
```

4. Open:

http://127.0.0.1:5500

The local server proxies `/api/*` and `/health` to the backend at:

http://127.0.0.1:8000

## Main UI areas

- Core: live enterprise metrics + animated agent fabric
- Ask: natural-language workflow console + execution trace
- Ops: workflow executions + agent activity
- Flow: architecture visualization

The frontend uses only endpoints already present in the current backend.
